(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 9459:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9814)), "C:\\Users\\mirne\\OneDrive\\Desktop\\nextjs-portfolio-main\\src\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2911)), "C:\\Users\\mirne\\OneDrive\\Desktop\\nextjs-portfolio-main\\src\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["C:\\Users\\mirne\\OneDrive\\Desktop\\nextjs-portfolio-main\\src\\app\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 226:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23))

/***/ }),

/***/ 370:
/***/ (() => {



/***/ }),

/***/ 7744:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9594));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8624));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 241));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8967));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6255));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2752))

/***/ }),

/***/ 8624:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_AboutSection)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 200 modules
var motion = __webpack_require__(635);
;// CONCATENATED MODULE: ./src/app/components/TabButton.jsx



const variants = {
    default: {
        width: 0
    },
    active: {
        width: "calc(100% - 0.75rem)"
    }
};
const TabButton = ({ active, selectTab, children })=>{
    const buttonClasses = active ? "text-white" : "text-[#ADB7BE]";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
        onClick: selectTab,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: `mr-3 font-semibold hover:text-white ${buttonClasses}`,
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                animate: active ? "active" : "default",
                variants: variants,
                className: "h-1 bg-primary-500 mt-2 mr-3"
            })
        ]
    });
};
/* harmony default export */ const components_TabButton = (TabButton);

// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.mjs + 4 modules
var fa = __webpack_require__(858);
;// CONCATENATED MODULE: ./src/app/components/AboutSection.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const TAB_DATA = [
    {
        title: "Skills",
        id: "skills",
        content: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: "flex flex-col gap-4 pl-2",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-row gap-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(fa/* FaNodeJs */.jPo, {
                            size: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(fa/* FaReact */.huN, {
                            size: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(fa/* FaAngular */.aRi, {
                            size: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(fa/* FaJava */.zEo, {
                            size: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(fa/* FaHtml5 */.gtO, {
                            size: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(fa/* FaCss3 */.FGx, {
                            size: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(fa/* FaGithub */.hJX, {
                            size: 30
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-row gap-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "Java Script Icon",
                            src: "/images/icons/js.png",
                            width: 30,
                            height: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "SQL Icon",
                            src: "/images/icons/sql-server.png",
                            width: 30,
                            height: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "Wordpress Icon",
                            src: "/images/icons/wordpress.png",
                            width: 30,
                            height: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "Photoshop Icon",
                            src: "/images/icons/photoshop.png",
                            width: 30,
                            height: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "Illustrator Icon",
                            src: "/images/icons/illustrator.png",
                            width: 30,
                            height: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "AdobeXD Icon",
                            src: "/images/icons/xd.png",
                            width: 30,
                            height: 30
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "Indesign Icon",
                            src: "/images/icons/indesign.png",
                            width: 30,
                            height: 30
                        })
                    ]
                })
            ]
        })
    },
    {
        title: "Education",
        id: "education",
        content: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: "list-disc pl-2",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: "Meta Front-End Developer Course"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: "Board Infinity Java Full-Stack Developer Course"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: "University of Ljubljana, Slovenia"
                })
            ]
        })
    },
    {
        title: "Certifications",
        id: "certifications",
        content: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: "list-disc pl-2",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: "Meta Front-End Developer - Professional Certificate"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: "Java Full-Stack Developer - Professional Certificate"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: "Meta Android Mobile Apps Developer - Fundamentals"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: "Google IT Specialist - Technical Support Fundamentals"
                })
            ]
        })
    }
];
const AboutSection = ()=>{
    const [tab, setTab] = (0,react_.useState)("skills");
    const [isPending, startTransition] = (0,react_.useTransition)();
    const handleTabChange = (id)=>{
        startTransition(()=>{
            setTab(id);
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "text-white",
        id: "about",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "md:grid md:grid-cols-2 gap-8 items-center py-8 px-4 xl:gap-16 sm:py-16 xl:px-16",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/images/about-image.png",
                    alt: "Picture of me",
                    className: "border-b border-purple-700",
                    width: 500,
                    height: 500
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mt-4 md:mt-0 text-left flex flex-col h-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-4xl font-bold text-white mb-4",
                            children: "About Me"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-base lg:text-lg",
                            children: "Experienced Full Stack Developer with a passion for crafting innovative solutions. Proficient in both front-end and back-end technologies, I thrive in creating seamless user experiences while ensuring robust functionality. Dedicated to continuous learning and staying abreast of emerging trends, I bring creativity and expertise to every project I undertake."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row justify-start mt-8",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(components_TabButton, {
                                    selectTab: ()=>handleTabChange("skills"),
                                    active: tab === "skills",
                                    children: [
                                        " ",
                                        "Skills",
                                        " "
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(components_TabButton, {
                                    selectTab: ()=>handleTabChange("education"),
                                    active: tab === "education",
                                    children: [
                                        " ",
                                        "Education",
                                        " "
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(components_TabButton, {
                                    selectTab: ()=>handleTabChange("certifications"),
                                    active: tab === "certifications",
                                    children: [
                                        " ",
                                        "Certifications",
                                        " "
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mt-8",
                            children: TAB_DATA.find((t)=>t.id === tab).content
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_AboutSection = (AboutSection);


/***/ }),

/***/ 2752:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__ default auto */ 



const EmailSection = ()=>{
    const [emailSubmitted, setEmailSubmitted] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [nameError, setNameError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [emailError, setEmailError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [messageError, setMessageError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleSubmit = async (e)=>{
        e.preventDefault();
        const data = {
            name: e.target.name.value.trim(),
            email: e.target.email.value.trim(),
            message: e.target.message.value.trim()
        };
        const trimmedName = data.name;
        const trimmedEmail = data.email;
        const trimmedMessage = data.message;
        if (trimmedName === "") {
            setNameError("Name field is required.");
            return;
        } else {
            setNameError("");
        }
        if (trimmedEmail === "") {
            setEmailError("Email field is required.");
            return;
        } else {
            setEmailError("");
        }
        if (trimmedMessage === "") {
            setMessageError("Message field is required.");
            return;
        } else {
            setMessageError("");
        }
        if (/^\s+$/.test(trimmedName)) {
            setNameError("Name cannot be whitespace.");
            return;
        } else {
            setNameError("");
        }
        if (/^\s+$/.test(trimmedEmail)) {
            setEmailError("Email cannot be whitespace.");
            return;
        } else {
            setEmailError("");
        }
        if (/^\s+$/.test(trimmedMessage)) {
            setMessageError("Message cannot be whitespace.");
            return;
        } else {
            setMessageError("");
        }
        const JSONdata = JSON.stringify(data);
        const endpoint = "https://getform.io/f/wardkwra";
        const options = {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSONdata
        };
        try {
            const response = await fetch(endpoint, options);
            if (response.ok) {
                console.log("Message sent.");
                setEmailSubmitted(true);
                setTimeout(()=>{
                    setEmailSubmitted(false);
                }, 3000); // 3000 milliseconds = 3 seconds
            } else {
                console.error("Failed to send message.");
            }
        } catch (error) {
            console.error("An error occurred:", error);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "contact",
        className: "grid md:grid-cols-2 my-12 md:my-12 py-24 gap-4",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        className: "text-xl font-bold text-white my-2",
                        children: "Let us Connect"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-[#ADB7BE] mb-4 max-w-md",
                        children: "I am currently looking for new opportunities, my inbox is always open. Whether you have a question or just want to say hi, I will try my best to get back to you!"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "socials flex flex-row gap-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                target: "_blank",
                                href: "https://github.com/Mirnessss",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    src: "/github-icon.svg",
                                    alt: "Github Icon",
                                    width: 32,
                                    height: 32
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                target: "_blank",
                                href: "https://www.linkedin.com/in/mirnes-kovacevic/",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    src: "/linkedin-icon.svg",
                                    alt: "Linkedin Icon",
                                    width: 32,
                                    height: 32
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: emailSubmitted ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "text-green-500 text-sm mt-2",
                    children: "Email sent successfully!"
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    className: "flex flex-col",
                    onSubmit: handleSubmit,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "name",
                                    className: "text-white block mb-2 text-sm font-medium",
                                    children: "Your Name"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    name: "name",
                                    type: "text",
                                    id: "name",
                                    required: true,
                                    className: "bg-[#18191E] border border-[#33353F] placeholder-[#9CA2A9] text-gray-100 text-sm rounded-lg block w-full p-2.5",
                                    placeholder: "Your Name"
                                }),
                                nameError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-red-500 text-sm mt-1",
                                    children: nameError
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "email",
                                    className: "text-white block mb-2 text-sm font-medium",
                                    children: "Your email"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    name: "email",
                                    type: "email",
                                    id: "email",
                                    required: true,
                                    className: "bg-[#18191E] border border-[#33353F] placeholder-[#9CA2A9] text-gray-100 text-sm rounded-lg block w-full p-2.5",
                                    placeholder: "jacob@google.com"
                                }),
                                emailError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-red-500 text-sm mt-1",
                                    children: emailError
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "message",
                                    className: "text-white block text-sm mb-2 font-medium",
                                    children: "Message"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                    name: "message",
                                    id: "message",
                                    className: "bg-[#18191E] border border-[#33353F] placeholder-[#9CA2A9] text-gray-100 text-sm rounded-lg block w-full p-2.5",
                                    placeholder: "Let's talk about..."
                                }),
                                messageError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-red-500 text-sm mt-1",
                                    children: messageError
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            type: "submit",
                            className: "bg-purple-700 hover:bg-primary-500 text-white font-medium py-2.5 px-5 rounded-lg w-full",
                            children: "Send Message"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmailSection);


/***/ }),

/***/ 8967:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7089);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const Footer = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: "footer text-white border-t border-purple-700",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container p-12 flex flex-col  justify-center items-center",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_scroll__WEBPACK_IMPORTED_MODULE_2__/* .Link */ .rU, {
                    to: "home",
                    spy: true,
                    smooth: true,
                    duration: 500,
                    className: "text-2xl cursor-pointer md:text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-purple-700 to-purple-500",
                    children: [
                        "MK",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-light text-white",
                            children: "DEV"
                        }),
                        "."
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "text-slate-200",
                    children: "All rights reserved."
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 6255:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_type_animation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9901);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(635);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7089);
/* __next_internal_client_entry_do_not_use__ default auto */ 




const HeroSection = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        id: "home",
        className: "lg:py-16",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "grid grid-cols-1 sm:grid-cols-12",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__/* .motion */ .E.div, {
                initial: {
                    opacity: 0,
                    scale: 0.5
                },
                animate: {
                    opacity: 1,
                    scale: 1
                },
                transition: {
                    duration: 0.5
                },
                className: "col-span-8 place-self-center text-center sm:text-left justify-self-start",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                        className: "text-white mb-4 text-3xl sm:text-5xl lg:text-8xl lg:leading-normal font-extrabold",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-transparent bg-clip-text bg-gradient-to-r from-purple-700 to-purple-500",
                                children: [
                                    "Hello, I am",
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_type_animation__WEBPACK_IMPORTED_MODULE_2__/* .TypeAnimation */ .e, {
                                sequence: [
                                    "Mirnes Kovacevic",
                                    1000,
                                    "Web Developer",
                                    1000,
                                    "Mobile Developer",
                                    1000,
                                    "Graphic Designer",
                                    1000
                                ],
                                wrapper: "span",
                                speed: 50,
                                repeat: Infinity
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-[#ADB7BE] text-base sm:text-lg mb-6 lg:text-xl",
                        children: "Full Stack Developer based in Augsburg, Germany!"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_scroll__WEBPACK_IMPORTED_MODULE_3__/* .Link */ .rU, {
                                to: "contact",
                                spy: true,
                                smooth: true,
                                duration: 500,
                                className: "px-6 inline-block py-3 w-full sm:w-fit cursor-pointer rounded-full text-white mr-4 bg-gradient-to-br from-purple-700 to-purple-500 hover:text-[#121212] hover:bg-slate-200",
                                children: "Hire Me"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                target: "_blank",
                                href: "https://drive.google.com/file/d/1TB8OsD6_FSRr34ZDcldY7J9rcUTLR8X-/view?usp=sharing",
                                className: "px-1 inline-block py-1 w-full sm:w-fit rounded-full bg-gradient-to-br from-purple-700 to-purple-500 hover:bg-slate-800 text-white mt-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "block bg-[#121212] hover:bg-gradient-to-br from-purple-700 to-purple-500 rounded-full px-5 py-2",
                                    children: "Resume"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroSection);


/***/ }),

/***/ 9594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/react-scroll/modules/index.js
var modules = __webpack_require__(7089);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./src/app/components/NavLink.jsx

 // Import Link as ScrollLink from react-scroll
const NavLink = ({ href, title })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(modules/* Link */.rU, {
        to: href,
        spy: true,
        smooth: true,
        duration: 500,
        className: "block cursor-pointer py-2 pl-3 pr-4 text-[#ADB7BE] sm:text-lg rounded-full md:p-2 hover:bg-purple-500 hover:text-white duration-300",
        children: title
    });
};
/* harmony default export */ const components_NavLink = (NavLink);

// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/solid/esm/Bars3Icon.js
var Bars3Icon = __webpack_require__(2876);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/solid/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(9322);
;// CONCATENATED MODULE: ./src/app/components/MenuOverlay.jsx



const MenuOverlay = ({ links })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "flex flex-col py-4 items-center justify-center text-xl rounded-b-xl h-[50dvh] bg-[#121212]/100",
        children: links.map((link, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(components_NavLink, {
                    href: link.path,
                    title: link.title
                })
            }, index))
    });
};
/* harmony default export */ const components_MenuOverlay = (MenuOverlay);

;// CONCATENATED MODULE: ./src/app/components/Navbar.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 
 // Import Link from react-scroll





const navLinks = [
    {
        title: "Home",
        path: "home"
    },
    {
        title: "About",
        path: "about"
    },
    {
        title: "Projects",
        path: "projects"
    },
    {
        title: "Contact",
        path: "contact"
    }
];
const Navbar = ()=>{
    const [navbarOpen, setNavbarOpen] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "fixed mx-auto border border-none top-0 left-0 right-0 z-10 bg-[#121212] bg-opacity-80",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex container lg:py-4 flex-wrap items-center justify-between mx-auto px-4 py-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(modules/* Link */.rU, {
                        to: "home",
                        spy: true,
                        smooth: true,
                        duration: 500,
                        className: "text-2xl cursor-pointer md:text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-purple-700 to-purple-500",
                        children: [
                            "MK",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "font-light text-white",
                                children: "DEV"
                            }),
                            "."
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mobile-menu block md:hidden",
                        children: !navbarOpen ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: ()=>setNavbarOpen(true),
                            className: "flex items-center px-3 py-2  text-slate-200 hover:text-white ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Bars3Icon/* default */.Z, {
                                className: "h-5 w-5"
                            })
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: ()=>setNavbarOpen(false),
                            className: "flex items-center px-3 py-2 text-slate-200 hover:text-white",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(XMarkIcon/* default */.Z, {
                                className: "h-5 w-5"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "menu hidden md:block md:w-auto",
                        id: "navbar",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "flex p-4 md:p-0 md:flex-row md:space-x-8 mt-0",
                            children: navLinks.map((link, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_NavLink, {
                                        href: link.path,
                                        title: link.title
                                    })
                                }, index))
                        })
                    })
                ]
            }),
            navbarOpen ? /*#__PURE__*/ jsx_runtime_.jsx(components_MenuOverlay, {
                links: navLinks
            }) : null
        ]
    });
};
/* harmony default export */ const components_Navbar = (Navbar);


/***/ }),

/***/ 241:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_ProjectsSection)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CodeBracketIcon.js
var CodeBracketIcon = __webpack_require__(8755);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/EyeIcon.js
var EyeIcon = __webpack_require__(1808);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/app/components/ProjectCard.jsx





const ProjectCard = ({ imgUrl, title, description, gitUrl, previewUrl, isOnWeb })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-52 md:h-72 rounded-t-xl relative group",
                style: {
                    background: `url(${imgUrl})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "overlay items-center justify-center absolute top-0 left-0 w-full h-full bg-[#181818] bg-opacity-0 hidden group-hover:flex group-hover:bg-opacity-80 transition-all duration-500 ",
                    children: [
                        isOnWeb && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: gitUrl,
                            className: "h-14 w-14 mr-2 border-2 relative rounded-full border-[#ADB7BE] hover:border-white group/link",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(CodeBracketIcon/* default */.Z, {
                                className: "h-10 w-10 text-[#ADB7BE] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2  cursor-pointer group-hover/link:text-white"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: previewUrl,
                            className: "h-14 w-14 border-2 relative rounded-full border-[#ADB7BE] hover:border-white group/link",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(EyeIcon/* default */.Z, {
                                className: "h-10 w-10 text-[#ADB7BE] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2  cursor-pointer group-hover/link:text-white"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-white rounded-b-xl mt-3 bg-[#181818]py-6 px-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        className: "text-xl font-semibold mb-2",
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-[#ADB7BE]",
                        children: description
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_ProjectCard = (ProjectCard);

;// CONCATENATED MODULE: ./src/app/components/ProjectTag.jsx


const ProjectTag = ({ name, onClick, isSelected })=>{
    const buttonStyles = isSelected ? "text-white border-primary-500" : "text-[#ADB7BE] border-slate-600 hover:border-white";
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: `${buttonStyles} rounded-full border-2 px-6 py-3 text-xl cursor-pointer`,
        onClick: ()=>onClick(name),
        children: name
    });
};
/* harmony default export */ const components_ProjectTag = (ProjectTag);

// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/utils/use-in-view.mjs + 2 modules
var use_in_view = __webpack_require__(4378);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 200 modules
var motion = __webpack_require__(635);
;// CONCATENATED MODULE: ./src/app/data/projectsData.js
const projectsData = [
    {
        id: 1,
        title: "Elena Joy Photography",
        description: "Portfolio Website fro Elena Joy",
        image: "/images/projects/ElenaJoy.png",
        tag: [
            "All",
            "Web"
        ],
        gitUrl: "https://github.com/Mirnessss/ElenaJoyProject",
        previewUrl: "https://i.imgur.com/MESxsac.jpg"
    },
    {
        id: 2,
        title: "Kungs Grillen Fast Food",
        description: "PFull Stack Web Application",
        image: "/images/projects/FastFood.png",
        tag: [
            "All",
            "Web"
        ],
        gitUrl: "https://github.com/Mirnessss/FastFoodOrdering",
        previewUrl: "https://i.imgur.com/wbGLqKa.png"
    },
    {
        id: 3,
        title: "Little Lemon Project",
        description: "CapStone Project from Meta Frontend Course",
        image: "/images/projects/LittleLemon.png",
        tag: [
            "All",
            "Web"
        ],
        gitUrl: "https://github.com/Mirnessss/LittleLemon",
        previewUrl: "https://i.imgur.com/4exmNgP.jpg"
    },
    {
        id: 4,
        title: "Avocado Salladsbar Website",
        description: "Frontend Web Application for Swedish restaurant",
        image: "/images/projects/avocado-salladsbar.png",
        tag: [
            "All",
            "Web"
        ],
        gitUrl: "https://i.imgur.com/T0z1Pd2.jpeg",
        previewUrl: "https://i.imgur.com/T0z1Pd2.jpeg"
    },
    {
        id: 5,
        title: "Travelly Website",
        description: "Simple website template for Travel Agency",
        image: "/images/projects/Travelly.png",
        tag: [
            "All",
            "Web"
        ],
        gitUrl: "https://github.com/Mirnessss/Travelly",
        previewUrl: "https://i.imgur.com/sHI5dCf.png"
    },
    {
        id: 6,
        title: "Netflix Landing Page Clone",
        description: "Landing Page Clone build with React",
        image: "/images/projects/NetflixLPClone.png",
        tag: [
            "All",
            "Web"
        ],
        gitUrl: "https://github.com/Mirnessss/netflix-clone",
        previewUrl: "https://i.imgur.com/ZEfs7Qj.png"
    },
    {
        id: 7,
        title: "Portfolio Website",
        description: "Simple portfolio website template with custom illustrations",
        image: "/images/projects/htmlcssportfolio.png",
        tag: [
            "All",
            "Web"
        ],
        gitUrl: "https://github.com/Mirnessss/PortfolioWebsite",
        previewUrl: "https://i.imgur.com/Ji0TRsd.png"
    },
    {
        id: 8,
        title: "On The Lake Front",
        description: "Book Cover Design",
        image: "/images/projects/bookcover1.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/lDkgktH.jpg"
    },
    {
        id: 9,
        title: "Cosmic Code",
        description: "Business Card Design",
        image: "/images/projects/buisnesscards1.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/y4p5heE.jpg"
    },
    {
        id: 10,
        title: "Nicola Thiele Aesthetics",
        description: "Logo Design",
        image: "/images/projects/logo1.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/2Ei7Czo.jpeg"
    },
    {
        id: 11,
        title: "Kayak Spokane",
        description: "Logo Design",
        image: "/images/projects/logo4.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/eF1yjCy.jpeg"
    },
    {
        id: 12,
        title: "Pure Twenty",
        description: "Emballage Design",
        image: "/images/projects/package1.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/bdQdVzI.jpeg"
    },
    {
        id: 12,
        title: "Jagoda Sok",
        description: "Emballage Design",
        image: "/images/projects/package2.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/eHAgk0Q.jpeg"
    },
    {
        id: 13,
        title: "Taps Arcade",
        description: "Logo Design",
        image: "/images/projects/logo2.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/wjRc1v6.jpeg"
    },
    {
        id: 13,
        title: "dkMute",
        description: "Stream Overlay Design",
        image: "/images/projects/streamoverlay1.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/DyTC5vG.jpeg"
    },
    {
        id: 14,
        title: "DJ Sonic",
        description: "Logo Design",
        image: "/images/projects/logo5.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/DOaH5v9.jpeg"
    },
    {
        id: 15,
        title: "Nightmare Gaming",
        description: "Logo Design",
        image: "/images/projects/logo3.png",
        tag: [
            "All",
            "Graphic Design"
        ],
        gitUrl: "/",
        previewUrl: "https://i.imgur.com/hMnE55O.jpeg"
    }
];
/* harmony default export */ const data_projectsData = (projectsData);

;// CONCATENATED MODULE: ./src/app/components/ProjectsSection.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const ProjectsSection = ()=>{
    const [tag, setTag] = (0,react_.useState)("Web");
    const ref = (0,react_.useRef)(null);
    const isInView = (0,use_in_view/* useInView */.Y)(ref, {
        once: true
    });
    const handleTagChange = (newTag)=>{
        setTag(newTag);
    };
    const filteredProjects = data_projectsData.filter((project)=>project.tag.includes(tag));
    const cardVariants = {
        initial: {
            y: 50,
            opacity: 0
        },
        animate: {
            y: 0,
            opacity: 1
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        id: "projects",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-center text-4xl font-bold text-white mt-4 mb-8 md:mb-12",
                children: "My Projects"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-white flex flex-row justify-center items-center gap-2 py-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components_ProjectTag, {
                        onClick: handleTagChange,
                        name: "Web",
                        isSelected: tag === "Web"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_ProjectTag, {
                        onClick: handleTagChange,
                        name: "Graphic Design",
                        isSelected: tag === "Graphic Design"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                ref: ref,
                className: "grid md:grid-cols-3 gap-8 md:gap-12",
                children: filteredProjects.map((project, index)=>/*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.li, {
                        variants: cardVariants,
                        initial: "initial",
                        animate: isInView ? "animate" : "initial",
                        transition: {
                            duration: 0.3,
                            delay: index * 0.4
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_ProjectCard, {
                            title: project.title,
                            description: project.description,
                            imgUrl: project.image,
                            gitUrl: project.gitUrl,
                            previewUrl: project.previewUrl,
                            isOnWeb: tag === "Web"
                        }, project.id)
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const components_ProjectsSection = (ProjectsSection);


/***/ }),

/***/ 2911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7155);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5023);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_1__);



const metadata = {
    visualViewport: "width=device-width, initial-scale=1.0, user-scalable=no",
    title: "Portfolio Website",
    description: "Experienced Full Stack Developer with a passion for crafting innovative solutions. Proficient in both front-end and back-end technologies, I thrive in creating seamless user experiences while ensuring robust functionality. Dedicated to continuous learning and staying abreast of emerging trends, I bring creativity and expertise to every project I undertake.",
    keywords: "portfolio, web development, front-end, back-end, front-end development",
    author: "Mirnes Kovacevic",
    url: "https://mirnes-dev.com",
    image: "/images/about-image.png",
    type: "website",
    locale: "en-US",
    theme: "dark",
    ogLanguage: "en_US",
    ogType: "website",
    ogUrl: "https://mirnes-dev.com",
    ogSiteName: "Mirnes Kovacevic",
    ogTitle: "Portfolio Website",
    ogDescription: "Experienced Full Stack Developer with a passion for crafting innovative solutions. Proficient in both front-end and back-end technologies, I thrive in creating seamless user experiences while ensuring robust functionality. Dedicated to continuous learning and staying abreast of emerging trends, I bring creativity and expertise to every project I undertake.",
    ogImage: "/images/about-image.png"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
            className: (next_font_google_target_css_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default().className),
            children: children
        })
    });
}


/***/ }),

/***/ 9814:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./src/app/components/HeroSection.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\mirne\OneDrive\Desktop\nextjs-portfolio-main\src\app\components\HeroSection.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const HeroSection = (__default__);
;// CONCATENATED MODULE: ./src/app/components/Navbar.jsx

const Navbar_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\mirne\OneDrive\Desktop\nextjs-portfolio-main\src\app\components\Navbar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Navbar_esModule, $$typeof: Navbar_$$typeof } = Navbar_proxy;
const Navbar_default_ = Navbar_proxy.default;


/* harmony default export */ const Navbar = (Navbar_default_);
;// CONCATENATED MODULE: ./src/app/components/AboutSection.jsx

const AboutSection_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\mirne\OneDrive\Desktop\nextjs-portfolio-main\src\app\components\AboutSection.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: AboutSection_esModule, $$typeof: AboutSection_$$typeof } = AboutSection_proxy;
const AboutSection_default_ = AboutSection_proxy.default;


/* harmony default export */ const AboutSection = (AboutSection_default_);
;// CONCATENATED MODULE: ./src/app/components/ProjectsSection.jsx

const ProjectsSection_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\mirne\OneDrive\Desktop\nextjs-portfolio-main\src\app\components\ProjectsSection.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: ProjectsSection_esModule, $$typeof: ProjectsSection_$$typeof } = ProjectsSection_proxy;
const ProjectsSection_default_ = ProjectsSection_proxy.default;


/* harmony default export */ const ProjectsSection = (ProjectsSection_default_);
;// CONCATENATED MODULE: ./src/app/components/EmailSection.jsx

const EmailSection_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\mirne\OneDrive\Desktop\nextjs-portfolio-main\src\app\components\EmailSection.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: EmailSection_esModule, $$typeof: EmailSection_$$typeof } = EmailSection_proxy;
const EmailSection_default_ = EmailSection_proxy.default;


/* harmony default export */ const EmailSection = (EmailSection_default_);
;// CONCATENATED MODULE: ./src/app/components/Footer.jsx

const Footer_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\mirne\OneDrive\Desktop\nextjs-portfolio-main\src\app\components\Footer.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Footer_esModule, $$typeof: Footer_$$typeof } = Footer_proxy;
const Footer_default_ = Footer_proxy.default;


/* harmony default export */ const Footer = (Footer_default_);
;// CONCATENATED MODULE: ./src/app/page.js







function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: "flex min-h-screen flex-col bg-[#121212]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mt-24 mx-auto px-12 py-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(HeroSection, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(AboutSection, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(ProjectsSection, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(EmailSection, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 3881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"16x16"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 5023:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,60,119], () => (__webpack_exec__(9459)));
module.exports = __webpack_exports__;

})();